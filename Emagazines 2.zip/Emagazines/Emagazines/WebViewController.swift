//
//  WebVc.swift
//  esports
//
//  Created by SAIL on 21/09/23.
//

import UIKit
import WebKit

class WebVc: UIViewController, UITextViewDelegate {
    
    @IBOutlet var webload: WKWebView!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false

        let web_url = URL(string:"https://192.168.23.66/8000")!
         let web_request = URLRequest(url: web_url)
         webload.load(web_request)

    }
    
  

}
